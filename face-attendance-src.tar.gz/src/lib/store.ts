import { get, set, update } from 'idb-keyval';
import { v4 as uuidv4 } from 'uuid';

export interface Person {
  id: string;
  name: string;
  descriptor: number[];
  thumbnailDataUrl: string;
  createdAt: string;
}

export interface AttendanceRecord {
  id: string;
  personId: string;
  name: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm:ss
  markedAt: string; // ISO string
}

const PEOPLE_KEY = 'face-attendance:people';
const ATTENDANCE_KEY = 'face-attendance:records';

// --- People ---

export async function getPeople(): Promise<Person[]> {
  return (await get<Person[]>(PEOPLE_KEY)) || [];
}

export async function getPerson(id: string): Promise<Person | undefined> {
  const people = await getPeople();
  return people.find((p) => p.id === id);
}

export async function addPerson(person: Omit<Person, 'id' | 'createdAt'>): Promise<Person> {
  const newPerson: Person = {
    ...person,
    id: uuidv4(),
    createdAt: new Date().toISOString(),
  };
  await update(PEOPLE_KEY, (val) => [...(val || []), newPerson]);
  return newPerson;
}

export async function deletePerson(id: string): Promise<void> {
  await update(PEOPLE_KEY, (val) => (val || []).filter((p: Person) => p.id !== id));
}

// --- Attendance ---

export async function getAttendanceRecords(): Promise<AttendanceRecord[]> {
  return (await get<AttendanceRecord[]>(ATTENDANCE_KEY)) || [];
}

export async function markAttendance(personId: string, name: string): Promise<{ success: boolean; record?: AttendanceRecord; reason?: string }> {
  const now = new Date();
  const dateStr = now.toLocaleDateString('en-CA', { year: 'numeric', month: '2-digit', day: '2-digit' }); // YYYY-MM-DD
  const timeStr = now.toLocaleTimeString('en-GB'); // HH:mm:ss

  let success = false;
  let newRecord: AttendanceRecord | undefined;
  let reason: string | undefined;

  await update(ATTENDANCE_KEY, (records) => {
    const safeRecords = records || [];
    
    // Check if already marked today
    const alreadyMarked = safeRecords.some((r: AttendanceRecord) => r.personId === personId && r.date === dateStr);
    
    if (alreadyMarked) {
      reason = 'already_marked';
      return safeRecords;
    }

    newRecord = {
      id: uuidv4(),
      personId,
      name,
      date: dateStr,
      time: timeStr,
      markedAt: now.toISOString(),
    };
    
    success = true;
    return [...safeRecords, newRecord];
  });

  return { success, record: newRecord, reason };
}

export async function deleteAttendanceRecord(id: string): Promise<void> {
  await update(ATTENDANCE_KEY, (val) => (val || []).filter((r: AttendanceRecord) => r.id !== id));
}
