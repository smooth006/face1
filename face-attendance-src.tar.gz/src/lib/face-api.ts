import * as faceapi from '@vladmandic/face-api';

const MODEL_URL = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@1.7.13/model/';

let modelsLoaded = false;

export async function loadFaceApiModels() {
  if (modelsLoaded) return;
  try {
    await Promise.all([
      faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
      faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
      faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
    ]);
    modelsLoaded = true;
  } catch (error) {
    console.error("Failed to load face-api models", error);
    throw error;
  }
}

export function isModelsLoaded() {
  return modelsLoaded;
}

export async function getFaceDescriptor(videoElement: HTMLVideoElement): Promise<{ descriptor: Float32Array; detection: faceapi.FaceDetection } | null> {
  if (!modelsLoaded) return null;

  const result = await faceapi
    .detectSingleFace(videoElement, new faceapi.TinyFaceDetectorOptions({ inputSize: 224, scoreThreshold: 0.5 }))
    .withFaceLandmarks()
    .withFaceDescriptor();

  if (!result) return null;

  return {
    descriptor: result.descriptor,
    detection: result.detection
  };
}

export function getEuclideanDistance(desc1: number[] | Float32Array, desc2: number[] | Float32Array): number {
  return faceapi.euclideanDistance(desc1, desc2);
}

export function findBestMatch(descriptor: Float32Array, people: { id: string; descriptor: number[] }[], threshold = 0.5): string | null {
  if (people.length === 0) return null;

  let bestMatchId: string | null = null;
  let minDistance = Infinity;

  for (const person of people) {
    const distance = getEuclideanDistance(descriptor, person.descriptor);
    if (distance < minDistance) {
      minDistance = distance;
      bestMatchId = person.id;
    }
  }

  if (minDistance <= threshold) {
    return bestMatchId;
  }

  return null;
}
