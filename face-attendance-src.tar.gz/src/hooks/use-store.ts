import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { getPeople, getPerson, addPerson, deletePerson, getAttendanceRecords, markAttendance, deleteAttendanceRecord, Person, AttendanceRecord } from '@/lib/store';

export const PEOPLE_QUERY_KEY = ['people'];
export const ATTENDANCE_QUERY_KEY = ['attendance'];

export function usePeople() {
  return useQuery({
    queryKey: PEOPLE_QUERY_KEY,
    queryFn: getPeople,
  });
}

export function useAttendanceRecords() {
  return useQuery({
    queryKey: ATTENDANCE_QUERY_KEY,
    queryFn: getAttendanceRecords,
  });
}

export function useAddPerson() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: addPerson,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: PEOPLE_QUERY_KEY });
    },
  });
}

export function useDeletePerson() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: deletePerson,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: PEOPLE_QUERY_KEY });
    },
  });
}

export function useMarkAttendance() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ personId, name }: { personId: string; name: string }) => markAttendance(personId, name),
    onSuccess: (data) => {
      if (data.success) {
        queryClient.invalidateQueries({ queryKey: ATTENDANCE_QUERY_KEY });
      }
    },
  });
}

export function useDeleteAttendanceRecord() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: deleteAttendanceRecord,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ATTENDANCE_QUERY_KEY });
    },
  });
}
