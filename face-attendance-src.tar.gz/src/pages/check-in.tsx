import { useEffect, useRef, useState, useCallback } from "react";
import { usePeople, useMarkAttendance } from "@/hooks/use-store";
import { loadFaceApiModels, isModelsLoaded, getFaceDescriptor, findBestMatch } from "@/lib/face-api";
import { Camera, CheckCircle2, User, AlertCircle, XCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import * as faceapi from "@vladmandic/face-api";

type DetectionState = "loading_models" | "starting_camera" | "looking" | "detected" | "recognized" | "already_marked" | "unknown" | "error";

export default function CheckIn() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const requestRef = useRef<number>();
  
  const [state, setState] = useState<DetectionState>("loading_models");
  const [message, setMessage] = useState("Loading AI models...");
  const [matchName, setMatchName] = useState<string | null>(null);
  const [errorDetails, setErrorDetails] = useState<string | null>(null);

  const { data: people } = usePeople();
  const markAttendance = useMarkAttendance();
  const markAttendanceMutate = markAttendance.mutateAsync;

  const startCamera = async () => {
    setState("starting_camera");
    setMessage("Starting camera...");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" } });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        // Wait for video to be ready
        await new Promise((resolve) => {
          if (videoRef.current) {
            videoRef.current.onloadedmetadata = () => {
              resolve(null);
            };
          }
        });
      }
      setState("looking");
      setMessage("Looking for a face...");
    } catch (err: any) {
      setState("error");
      setMessage("Camera access denied");
      setErrorDetails(err.message || "Could not access the camera. Please allow permissions.");
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (requestRef.current) {
      cancelAnimationFrame(requestRef.current);
    }
  };

  useEffect(() => {
    let mounted = true;
    
    const init = async () => {
      try {
        await loadFaceApiModels();
        if (mounted) {
          startCamera();
        }
      } catch (err: any) {
        if (mounted) {
          setState("error");
          setMessage("Failed to load models");
          setErrorDetails(err.message || "An error occurred while loading face recognition models.");
        }
      }
    };

    init();

    return () => {
      mounted = false;
      stopCamera();
    };
  }, []);

  const drawBox = (detection: faceapi.FaceDetection, color: string) => {
    if (!canvasRef.current || !videoRef.current) return;
    const canvas = canvasRef.current;
    const video = videoRef.current;
    
    const displaySize = { width: video.videoWidth, height: video.videoHeight };
    faceapi.matchDimensions(canvas, displaySize);
    
    const resizedDetection = faceapi.resizeResults(detection, displaySize);
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const box = resizedDetection.box;
      
      ctx.strokeStyle = color;
      ctx.lineWidth = 3;
      ctx.strokeRect(box.x, box.y, box.width, box.height);
    }
  };

  const clearCanvas = () => {
    if (!canvasRef.current) return;
    const ctx = canvasRef.current.getContext('2d');
    if (ctx) {
      ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
    }
  };

  const processFrame = useCallback(async () => {
    if (!videoRef.current || !people || state === "error" || state === "loading_models" || state === "starting_camera") {
      requestRef.current = requestAnimationFrame(processFrame);
      return;
    }

    // Skip processing if we just marked someone, give it a cooldown
    if (state === "recognized" || state === "already_marked" || state === "unknown") {
      // Keep state for a few seconds
      await new Promise(r => setTimeout(r, 2000));
      setState("looking");
      setMessage("Looking for a face...");
      setMatchName(null);
      clearCanvas();
    }

    if (state === "looking" || state === "detected") {
      try {
        const result = await getFaceDescriptor(videoRef.current);
        
        if (!result) {
          if (state !== "looking") {
            setState("looking");
            setMessage("Looking for a face...");
            clearCanvas();
          }
        } else {
          if (state !== "detected" && state !== "recognized") {
            setState("detected");
            setMessage("Face detected. Identifying...");
          }
          
          drawBox(result.detection, '#eab308'); // Yellow box while identifying

          const matchId = findBestMatch(result.descriptor, people.map(p => ({ id: p.id, descriptor: p.descriptor })));
          
          if (matchId) {
            const person = people.find(p => p.id === matchId);
            if (person) {
              drawBox(result.detection, '#22c55e'); // Green box for success
              
              try {
                const res = await markAttendanceMutate({ personId: person.id, name: person.name });
                if (res.success) {
                  setState("recognized");
                  setMessage(`Marked present: ${person.name}`);
                  setMatchName(person.name);
                } else if (res.reason === "already_marked") {
                  setState("already_marked");
                  setMessage(`${person.name} already marked today`);
                  setMatchName(person.name);
                }
              } catch (e) {
                console.error("Failed to mark attendance", e);
              }
            }
          } else {
            drawBox(result.detection, '#ef4444'); // Red box for unknown
            setState("unknown");
            setMessage("Unknown face. Please register.");
          }
        }
      } catch (err) {
        console.error("Frame processing error:", err);
      }
    }

    requestRef.current = requestAnimationFrame(processFrame);
  }, [state, people, markAttendanceMutate]);

  useEffect(() => {
    if (state === "looking" && !requestRef.current) {
      requestRef.current = requestAnimationFrame(processFrame);
    }
    return () => {
      if (requestRef.current) {
        cancelAnimationFrame(requestRef.current);
        requestRef.current = undefined;
      }
    };
  }, [state, processFrame]);

  return (
    <div className="space-y-6 animate-in fade-in duration-500 max-w-3xl mx-auto">
      <div className="text-center">
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Live Check-In</h1>
        <p className="text-muted-foreground mt-1">Look at the camera to mark your attendance.</p>
      </div>

      <div className="bg-card border border-card-border rounded-2xl shadow-sm overflow-hidden flex flex-col items-center p-6 relative">
        <div className={cn(
          "w-full max-w-xl aspect-video rounded-xl overflow-hidden relative bg-black",
          state === "error" ? "bg-muted" : ""
        )}>
          {state === "error" ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6 bg-muted text-muted-foreground">
              <AlertCircle size={48} className="mb-4 text-destructive" />
              <p className="font-medium text-lg text-foreground">{message}</p>
              <p className="text-sm mt-2">{errorDetails}</p>
              <button 
                onClick={startCamera}
                className="mt-6 px-4 py-2 bg-primary text-primary-foreground rounded-md font-medium hover:bg-primary/90 transition-colors"
              >
                Retry
              </button>
            </div>
          ) : (
            <>
              <video 
                ref={videoRef} 
                autoPlay 
                playsInline 
                muted 
                className="absolute inset-0 w-full h-full object-cover transform -scale-x-100"
              />
              <canvas 
                ref={canvasRef} 
                className="absolute inset-0 w-full h-full object-cover transform -scale-x-100 z-10"
              />
              
              {(state === "loading_models" || state === "starting_camera") && (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 text-white z-20 backdrop-blur-sm">
                  <div className="w-12 h-12 border-4 border-primary/30 border-t-primary rounded-full animate-spin mb-4" />
                  <p className="font-medium">{message}</p>
                </div>
              )}
            </>
          )}
        </div>

        <div className="mt-8 w-full max-w-xl flex items-center justify-center">
          <div className={cn(
            "flex items-center gap-3 px-6 py-3 rounded-full border transition-all duration-300",
            state === "looking" ? "bg-secondary text-secondary-foreground border-secondary-border" :
            state === "detected" ? "bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-500/10 dark:border-yellow-500/20 dark:text-yellow-500" :
            state === "recognized" ? "bg-green-50 text-green-700 border-green-200 dark:bg-green-500/10 dark:border-green-500/20 dark:text-green-500 scale-105" :
            state === "already_marked" ? "bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-500/10 dark:border-blue-500/20 dark:text-blue-500" :
            state === "unknown" ? "bg-destructive/10 text-destructive border-destructive/20" :
            "bg-muted text-muted-foreground border-border"
          )}>
            {state === "recognized" ? <CheckCircle2 size={24} /> :
             state === "already_marked" ? <CheckCircle2 size={24} /> :
             state === "unknown" ? <XCircle size={24} /> :
             state === "detected" ? <User size={24} className="animate-pulse" /> :
             state === "looking" ? <Camera size={24} /> :
             <AlertCircle size={24} />}
            <span className="font-medium text-lg">{message}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
