import { useState } from "react";
import { usePeople, useAttendanceRecords } from "@/hooks/use-store";
import { format, subDays, isAfter, isBefore, startOfDay, endOfDay } from "date-fns";
import { Download, Search, History, Calendar as CalendarIcon, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Records() {
  const { data: people, isLoading: peopleLoading } = usePeople();
  const { data: records, isLoading: recordsLoading } = useAttendanceRecords();
  const { toast } = useToast();

  const [dateFilter, setDateFilter] = useState<"today" | "7days" | "30days" | "all">("today");
  const [search, setSearch] = useState("");

  const isLoading = peopleLoading || recordsLoading;

  const filteredRecords = records?.filter((record) => {
    // Search filter
    if (search && !record.name.toLowerCase().includes(search.toLowerCase())) {
      return false;
    }

    // Date filter
    const recordDate = new Date(record.markedAt);
    const now = new Date();
    
    if (dateFilter === "today") {
      return recordDate >= startOfDay(now) && recordDate <= endOfDay(now);
    } else if (dateFilter === "7days") {
      return recordDate >= subDays(startOfDay(now), 7);
    } else if (dateFilter === "30days") {
      return recordDate >= subDays(startOfDay(now), 30);
    }
    
    return true;
  }).sort((a, b) => new Date(b.markedAt).getTime() - new Date(a.markedAt).getTime()) || [];

  const handleExportCSV = () => {
    if (filteredRecords.length === 0) {
      toast({ title: "No records to export", variant: "destructive" });
      return;
    }

    const headers = ["Name", "Date", "Time"];
    const rows = filteredRecords.map(r => [
      `"${r.name.replace(/"/g, '""')}"`,
      r.date,
      r.time
    ]);

    const csvContent = [
      headers.join(","),
      ...rows.map(r => r.join(","))
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    
    const dateStr = format(new Date(), "yyyy-MM-dd");
    link.setAttribute("href", url);
    link.setAttribute("download", `attendance-${dateStr}.csv`);
    link.style.visibility = "hidden";
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({ title: "Export complete", description: "CSV file has been downloaded." });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500 max-w-5xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Attendance Records</h1>
          <p className="text-muted-foreground mt-1">View and export check-in history.</p>
        </div>
        
        <button
          onClick={handleExportCSV}
          disabled={filteredRecords.length === 0}
          className="flex items-center justify-center gap-2 px-4 py-2 bg-primary text-primary-foreground font-medium rounded-lg hover:bg-primary/90 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Download size={18} />
          <span>Export CSV</span>
        </button>
      </div>

      <div className="bg-card border border-card-border rounded-2xl shadow-sm overflow-hidden">
        <div className="p-4 md:p-6 border-b border-card-border flex flex-col sm:flex-row gap-4 justify-between bg-muted/20">
          <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0 hide-scrollbar">
            {(["today", "7days", "30days", "all"] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setDateFilter(filter)}
                className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                  dateFilter === filter 
                    ? "bg-secondary text-secondary-foreground border border-secondary-border" 
                    : "bg-transparent text-muted-foreground hover:bg-muted"
                }`}
              >
                {filter === "today" ? "Today" : 
                 filter === "7days" ? "Last 7 Days" : 
                 filter === "30days" ? "Last 30 Days" : "All Time"}
              </button>
            ))}
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={16} />
            <input
              type="text"
              placeholder="Search names..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-background border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring text-sm transition-all"
            />
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center p-12">
            <div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
          </div>
        ) : filteredRecords.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-16 text-center text-muted-foreground">
            <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mb-4">
              <History size={24} />
            </div>
            <p className="text-lg font-medium text-foreground">No records found</p>
            <p className="text-sm mt-1 max-w-md">
              {search 
                ? `No records match your search for "${search}".` 
                : "No attendance records match the selected date filter."}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-muted-foreground uppercase bg-muted/30">
                <tr>
                  <th className="px-6 py-4 font-medium">Person</th>
                  <th className="px-6 py-4 font-medium">Date</th>
                  <th className="px-6 py-4 font-medium">Time</th>
                  <th className="px-6 py-4 font-medium text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-card-border">
                {filteredRecords.map((record) => {
                  const person = people?.find(p => p.id === record.personId);
                  
                  return (
                    <tr key={record.id} className="hover:bg-muted/10 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          {person?.thumbnailDataUrl ? (
                            <img 
                              src={person.thumbnailDataUrl} 
                              alt={person.name} 
                              className="w-8 h-8 rounded-full object-cover border border-border" 
                            />
                          ) : (
                            <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center text-foreground font-medium text-xs border border-border">
                              {record.name.charAt(0).toUpperCase()}
                            </div>
                          )}
                          <span className="font-medium text-foreground">{record.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-muted-foreground">
                        <div className="flex items-center gap-2">
                          <CalendarIcon size={14} />
                          {format(new Date(record.markedAt), "MMM d, yyyy")}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-muted-foreground">
                        {record.time}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-green-50 text-green-600 dark:bg-green-500/10 dark:text-green-500 border border-green-200 dark:border-green-500/20 text-xs font-medium">
                          <CheckCircle2 size={14} />
                          Present
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
