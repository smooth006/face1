import { useEffect, useRef, useState, useCallback } from "react";
import { useLocation } from "wouter";
import { useAddPerson } from "@/hooks/use-store";
import { loadFaceApiModels, isModelsLoaded, getFaceDescriptor } from "@/lib/face-api";
import { Camera, UserPlus, AlertCircle, ArrowRight, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import * as faceapi from "@vladmandic/face-api";

const TARGET_SAMPLES = 10;

type RegistrationState = "loading_models" | "ready" | "starting_camera" | "capturing" | "processing" | "success" | "error";

export default function Register() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const addPerson = useAddPerson();
  const addPersonMutate = addPerson.mutateAsync;

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const requestRef = useRef<number>();
  
  const [state, setState] = useState<RegistrationState>("loading_models");
  const [name, setName] = useState("");
  const [samples, setSamples] = useState<Float32Array[]>([]);
  const [thumbnailUrl, setThumbnailUrl] = useState<string | null>(null);
  const [errorDetails, setErrorDetails] = useState<string | null>(null);

  const startCamera = async () => {
    setState("starting_camera");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" } });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await new Promise((resolve) => {
          if (videoRef.current) {
            videoRef.current.onloadedmetadata = () => {
              resolve(null);
            };
          }
        });
      }
      setState("ready");
    } catch (err: any) {
      setState("error");
      setErrorDetails(err.message || "Could not access the camera. Please allow permissions.");
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (requestRef.current) {
      cancelAnimationFrame(requestRef.current);
    }
  };

  useEffect(() => {
    let mounted = true;
    const init = async () => {
      try {
        await loadFaceApiModels();
        if (mounted) {
          startCamera();
        }
      } catch (err: any) {
        if (mounted) {
          setState("error");
          setErrorDetails("An error occurred while loading face recognition models.");
        }
      }
    };
    init();

    return () => {
      mounted = false;
      stopCamera();
    };
  }, []);

  const captureThumbnail = () => {
    if (!videoRef.current) return null;
    const video = videoRef.current;
    const canvas = document.createElement("canvas");
    canvas.width = 150;
    canvas.height = 150;
    const ctx = canvas.getContext("2d");
    if (!ctx) return null;
    
    // Crop center square
    const size = Math.min(video.videoWidth, video.videoHeight);
    const sx = (video.videoWidth - size) / 2;
    const sy = (video.videoHeight - size) / 2;
    
    // Draw mirrored
    ctx.translate(canvas.width, 0);
    ctx.scale(-1, 1);
    ctx.drawImage(video, sx, sy, size, size, 0, 0, canvas.width, canvas.height);
    
    return canvas.toDataURL("image/jpeg", 0.8);
  };

  const drawBox = (detection: faceapi.FaceDetection) => {
    if (!canvasRef.current || !videoRef.current) return;
    const canvas = canvasRef.current;
    const video = videoRef.current;
    
    const displaySize = { width: video.videoWidth, height: video.videoHeight };
    faceapi.matchDimensions(canvas, displaySize);
    
    const resizedDetection = faceapi.resizeResults(detection, displaySize);
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const box = resizedDetection.box;
      
      ctx.strokeStyle = '#22c55e'; // Green box
      ctx.lineWidth = 3;
      ctx.strokeRect(box.x, box.y, box.width, box.height);
    }
  };

  const processFrame = useCallback(async () => {
    if (!videoRef.current || state !== "capturing") {
      if (state === "capturing") requestRef.current = requestAnimationFrame(processFrame);
      return;
    }

    try {
      const result = await getFaceDescriptor(videoRef.current);
      
      if (result) {
        drawBox(result.detection);
        
        setSamples(prev => {
          const newSamples = [...prev, result.descriptor];
          
          if (newSamples.length === 1 && !thumbnailUrl) {
            setThumbnailUrl(captureThumbnail());
          }
          
          if (newSamples.length >= TARGET_SAMPLES) {
            finishCapture(newSamples);
            return newSamples;
          }
          return newSamples;
        });
      } else {
        if (canvasRef.current) {
          const ctx = canvasRef.current.getContext('2d');
          if (ctx) ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
        }
      }
    } catch (err) {
      console.error("Frame processing error:", err);
    }

    if (state === "capturing") {
      // Small delay between captures to get diverse angles
      setTimeout(() => {
        requestRef.current = requestAnimationFrame(processFrame);
      }, 300);
    }
  }, [state, thumbnailUrl]);

  useEffect(() => {
    if (state === "capturing" && !requestRef.current) {
      requestRef.current = requestAnimationFrame(processFrame);
    }
    return () => {
      if (requestRef.current) {
        cancelAnimationFrame(requestRef.current);
        requestRef.current = undefined;
      }
    };
  }, [state, processFrame]);

  const startCapture = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      toast({ title: "Name is required", variant: "destructive" });
      return;
    }
    setState("capturing");
    setSamples([]);
  };

  const finishCapture = async (finalSamples: Float32Array[]) => {
    setState("processing");
    stopCamera();
    
    // Average the descriptors element-wise
    if (finalSamples.length === 0) {
      setState("error");
      setErrorDetails("Failed to capture face data.");
      return;
    }
    
    const descriptorLen = finalSamples[0].length;
    const avgDescriptor = new Float32Array(descriptorLen);
    
    for (let i = 0; i < descriptorLen; i++) {
      let sum = 0;
      for (const sample of finalSamples) {
        sum += sample[i];
      }
      avgDescriptor[i] = sum / finalSamples.length;
    }

    try {
      await addPersonMutate({
        name: name.trim(),
        descriptor: Array.from(avgDescriptor),
        thumbnailDataUrl: thumbnailUrl || "",
      });
      
      setState("success");
      toast({ title: "Registration complete", description: `${name} has been successfully registered.` });
      
      setTimeout(() => {
        setLocation("/people");
      }, 1500);
    } catch (err: any) {
      setState("error");
      setErrorDetails(err.message || "Failed to save user data.");
    }
  };

  const progress = Math.min(100, Math.round((samples.length / TARGET_SAMPLES) * 100));

  return (
    <div className="space-y-6 animate-in fade-in duration-500 max-w-3xl mx-auto">
      <div className="text-center">
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Register Person</h1>
        <p className="text-muted-foreground mt-1">Add a new face to the attendance system.</p>
      </div>

      <div className="bg-card border border-card-border rounded-2xl shadow-sm overflow-hidden p-6 md:p-8">
        {state === "success" ? (
          <div className="flex flex-col items-center justify-center text-center py-12">
            <div className="w-20 h-20 bg-green-50 text-green-500 rounded-full flex items-center justify-center mb-6">
              <UserPlus size={40} />
            </div>
            <h2 className="text-2xl font-bold mb-2">Registration Successful</h2>
            <p className="text-muted-foreground mb-8">Redirecting to people list...</p>
            <Loader2 className="animate-spin text-primary" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="flex flex-col">
              <h3 className="font-medium text-lg mb-4">1. Camera View</h3>
              <div className={cn(
                "w-full aspect-video md:aspect-square rounded-xl overflow-hidden relative bg-black",
                state === "error" ? "bg-muted" : ""
              )}>
                {state === "error" ? (
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6 bg-muted text-muted-foreground">
                    <AlertCircle size={32} className="mb-4 text-destructive" />
                    <p className="font-medium text-foreground">Camera Error</p>
                    <p className="text-xs mt-2">{errorDetails}</p>
                    <button 
                      onClick={startCamera}
                      className="mt-4 px-3 py-1.5 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:bg-primary/90 transition-colors"
                    >
                      Retry
                    </button>
                  </div>
                ) : (
                  <>
                    <video 
                      ref={videoRef} 
                      autoPlay 
                      playsInline 
                      muted 
                      className="absolute inset-0 w-full h-full object-cover transform -scale-x-100"
                    />
                    <canvas 
                      ref={canvasRef} 
                      className="absolute inset-0 w-full h-full object-cover transform -scale-x-100 z-10"
                    />
                    
                    {(state === "loading_models" || state === "starting_camera" || state === "processing") && (
                      <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 text-white z-20 backdrop-blur-sm">
                        <Loader2 className="animate-spin mb-4" size={32} />
                        <p className="font-medium">
                          {state === "loading_models" ? "Loading AI models..." : 
                           state === "starting_camera" ? "Starting camera..." : "Processing face data..."}
                        </p>
                      </div>
                    )}
                  </>
                )}
              </div>

              {state === "capturing" && (
                <div className="mt-4">
                  <div className="flex justify-between text-sm mb-1 font-medium">
                    <span>Capturing face samples...</span>
                    <span>{progress}%</span>
                  </div>
                  <div className="w-full bg-secondary rounded-full h-2 overflow-hidden">
                    <div 
                      className="bg-primary h-full transition-all duration-300" 
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground mt-2 text-center">
                    Please slowly move your head side to side.
                  </p>
                </div>
              )}
            </div>

            <div className="flex flex-col justify-center">
              <h3 className="font-medium text-lg mb-4">2. Person Details</h3>
              <form onSubmit={startCapture} className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-foreground mb-1.5">
                    Full Name
                  </label>
                  <input
                    id="name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    disabled={state !== "ready" && state !== "error"}
                    className="w-full px-4 py-2 bg-input border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent transition-all"
                    placeholder="e.g. Jane Doe"
                    required
                  />
                </div>

                <div className="pt-4">
                  <button
                    type="submit"
                    disabled={state !== "ready" || !name.trim()}
                    className="w-full py-3 px-4 bg-primary text-primary-foreground font-medium rounded-lg hover:bg-primary/90 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 group"
                  >
                    <span>Start Face Capture</span>
                    <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
                  </button>
                  <p className="text-xs text-muted-foreground mt-3 text-center">
                    The camera will take about {TARGET_SAMPLES} samples to build an accurate profile.
                  </p>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
