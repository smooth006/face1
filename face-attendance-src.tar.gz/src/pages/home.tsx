import { usePeople, useAttendanceRecords } from "@/hooks/use-store";
import { format } from "date-fns";
import { Link } from "wouter";
import { Camera, UserPlus, Users, Activity, CheckCircle2 } from "lucide-react";

export default function Home() {
  const { data: people } = usePeople();
  const { data: records } = useAttendanceRecords();

  const today = format(new Date(), "yyyy-MM-dd");
  const todayRecords = records?.filter((r) => r.date === today) || [];
  const peopleCount = people?.length || 0;
  const attendanceRate = peopleCount > 0 ? Math.round((todayRecords.length / peopleCount) * 100) : 0;

  const recentRecords = [...todayRecords].sort((a, b) => new Date(b.markedAt).getTime() - new Date(a.markedAt).getTime()).slice(0, 5);

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Good Morning</h1>
        <p className="text-muted-foreground mt-1">Here's today's attendance overview.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-card border border-card-border rounded-xl p-6 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <h3 className="font-medium text-muted-foreground">Today's Attendance</h3>
            <Activity className="text-primary" size={20} />
          </div>
          <div className="mt-4 flex items-baseline gap-2">
            <span className="text-4xl font-bold">{todayRecords.length}</span>
            <span className="text-muted-foreground">/ {peopleCount} people</span>
          </div>
          <div className="mt-4 w-full bg-secondary rounded-full h-2 overflow-hidden">
            <div 
              className="bg-primary h-full transition-all duration-1000 ease-out" 
              style={{ width: `${attendanceRate}%` }}
            />
          </div>
        </div>

        <div className="md:col-span-2 grid grid-cols-2 gap-4">
          <Link href="/check-in" className="group">
            <div className="bg-primary hover:bg-primary/90 text-primary-foreground border border-primary-border rounded-xl p-6 shadow-sm h-full flex flex-col items-center justify-center text-center transition-colors cursor-pointer active:scale-[0.98]">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                <Camera size={24} />
              </div>
              <h3 className="font-medium text-lg">Start Check-In</h3>
              <p className="text-primary-foreground/80 text-sm mt-1">Open camera to mark attendance</p>
            </div>
          </Link>
          
          <div className="grid grid-rows-2 gap-4">
            <Link href="/register" className="group">
              <div className="bg-card hover:bg-accent border border-card-border rounded-xl p-4 shadow-sm h-full flex items-center gap-4 transition-colors cursor-pointer">
                <div className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center text-foreground group-hover:bg-background transition-colors">
                  <UserPlus size={20} />
                </div>
                <div>
                  <h3 className="font-medium">Register Person</h3>
                  <p className="text-muted-foreground text-xs">Add a new face</p>
                </div>
              </div>
            </Link>
            
            <Link href="/people" className="group">
              <div className="bg-card hover:bg-accent border border-card-border rounded-xl p-4 shadow-sm h-full flex items-center gap-4 transition-colors cursor-pointer">
                <div className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center text-foreground group-hover:bg-background transition-colors">
                  <Users size={20} />
                </div>
                <div>
                  <h3 className="font-medium">Manage People</h3>
                  <p className="text-muted-foreground text-xs">View registered faces</p>
                </div>
              </div>
            </Link>
          </div>
        </div>
      </div>

      <div className="bg-card border border-card-border rounded-xl shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-card-border flex justify-between items-center bg-muted/30">
          <h3 className="font-medium">Recent Check-ins</h3>
          <Link href="/records" className="text-sm text-primary hover:underline">View all</Link>
        </div>
        <div className="divide-y divide-card-border">
          {recentRecords.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground">
              <p>No check-ins yet today.</p>
            </div>
          ) : (
            recentRecords.map((record) => {
              const person = people?.find(p => p.id === record.personId);
              return (
                <div key={record.id} className="p-4 px-6 flex items-center justify-between hover:bg-muted/20 transition-colors">
                  <div className="flex items-center gap-3">
                    {person?.thumbnailDataUrl ? (
                      <img src={person.thumbnailDataUrl} alt={person.name} className="w-10 h-10 rounded-full object-cover border border-border" />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-muted-foreground font-medium border border-border">
                        {record.name.charAt(0).toUpperCase()}
                      </div>
                    )}
                    <div>
                      <p className="font-medium">{record.name}</p>
                      <p className="text-xs text-muted-foreground">{record.time}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-green-600 dark:text-green-500 bg-green-50 dark:bg-green-500/10 px-3 py-1 rounded-full border border-green-200 dark:border-green-500/20">
                    <CheckCircle2 size={16} />
                    <span>Present</span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
