import { useState } from "react";
import { usePeople, useDeletePerson } from "@/hooks/use-store";
import { Trash2, Users, AlertCircle, Search } from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function People() {
  const { data: people, isLoading } = usePeople();
  const deletePerson = useDeletePerson();
  const { toast } = useToast();
  
  const [search, setSearch] = useState("");
  const [personToDelete, setPersonToDelete] = useState<string | null>(null);

  const filteredPeople = people?.filter(p => p.name.toLowerCase().includes(search.toLowerCase())) || [];

  const handleDelete = async () => {
    if (!personToDelete) return;
    
    try {
      await deletePerson.mutateAsync(personToDelete);
      toast({ title: "Person deleted successfully" });
    } catch (err) {
      toast({ title: "Failed to delete person", variant: "destructive" });
    } finally {
      setPersonToDelete(null);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500 max-w-4xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Registered People</h1>
          <p className="text-muted-foreground mt-1">Manage faces stored in the attendance system.</p>
        </div>
        
        <div className="relative w-full md:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
          <input
            type="text"
            placeholder="Search names..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-card border border-card-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent transition-all"
          />
        </div>
      </div>

      <div className="bg-card border border-card-border rounded-2xl shadow-sm overflow-hidden">
        {isLoading ? (
          <div className="flex justify-center p-12">
            <div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
          </div>
        ) : filteredPeople.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-16 text-center text-muted-foreground">
            <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mb-4">
              {search ? <Search size={24} /> : <Users size={24} />}
            </div>
            <p className="text-lg font-medium text-foreground">
              {search ? "No matches found" : "No people registered yet"}
            </p>
            <p className="text-sm mt-1 max-w-md">
              {search 
                ? `No one matches "${search}". Try a different name.` 
                : "Register faces using the Check-In > Register page to start tracking attendance."}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-card-border">
            {filteredPeople.map((person) => (
              <div key={person.id} className="p-4 px-6 flex items-center justify-between hover:bg-muted/20 transition-colors group">
                <div className="flex items-center gap-4">
                  {person.thumbnailDataUrl ? (
                    <img 
                      src={person.thumbnailDataUrl} 
                      alt={person.name} 
                      className="w-12 h-12 rounded-full object-cover border border-border shadow-sm" 
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center text-foreground font-medium text-lg border border-border shadow-sm">
                      {person.name.charAt(0).toUpperCase()}
                    </div>
                  )}
                  <div>
                    <h3 className="font-medium text-foreground">{person.name}</h3>
                    <p className="text-xs text-muted-foreground">
                      Added {format(new Date(person.createdAt), "MMM d, yyyy")}
                    </p>
                  </div>
                </div>
                
                <button
                  onClick={() => setPersonToDelete(person.id)}
                  className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-md transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100"
                  aria-label={`Delete ${person.name}`}
                >
                  <Trash2 size={18} />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      <AlertDialog open={!!personToDelete} onOpenChange={(open) => !open && setPersonToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertCircle className="text-destructive" size={20} />
              Delete Person
            </AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this person? This will remove their face data from the system, but their past attendance records will be preserved. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
